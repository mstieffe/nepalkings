# __init__.py
from .games import games
from .auth import auth
from .challenges import challenges
